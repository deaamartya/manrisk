<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class PengukuranIndhanTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('pengukuran_indhan')->delete();
        
        
        
    }
}