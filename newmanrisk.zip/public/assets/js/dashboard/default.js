// greeting
var today = new Date()
var curHr = today.getHours()
//small chart-1
